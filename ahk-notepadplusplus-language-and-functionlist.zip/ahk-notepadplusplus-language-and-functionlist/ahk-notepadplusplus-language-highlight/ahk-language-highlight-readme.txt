
Complete both sections, the overrideMap.xml and Language Highlight Sections

Both sections have to be completed for the language highlight and the function list to work.

#WINDOWS:

Copy and paste ahk.xml into this directory.

C:\Users\USERNAME\AppData\Roaming\Notepad++\userDefineLangs

Then restart Notepad++.

Open your .ahk file.

Select the ahk language from the bottom of the language menu.

Open the function list by going to view, then ticking the function list at the bottom of the view menu.

You might have to click on and off the ahk file, or click refresh on the functional, to see if everything worked properly.

But if it did work, you should see all your functions and all the hot keys with:: in the name.

